import { Manrope, Montserrat, Onest } from "next/font/google";

/** ChaiUI type: Manrope for text, Montserrat for highlights, card titles and numbers, Onest for the wordmark. */
export const manrope = Manrope({ subsets: ["latin"], variable: "--font-manrope", display: "swap" });
export const montserrat = Montserrat({ subsets: ["latin"], variable: "--font-montserrat", display: "swap" });
export const onest = Onest({ subsets: ["latin"], variable: "--font-onest", display: "swap" });
