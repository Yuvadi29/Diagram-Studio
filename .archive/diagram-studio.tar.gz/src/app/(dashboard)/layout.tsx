import { Suspense } from "react";
import { AppSidebar } from "@/components/shared/app-sidebar";
import { getProfile, requireUser } from "@/lib/auth/session";

export default async function DashboardLayout({ children }: { children: React.ReactNode }) {
  const { user } = await requireUser();
  const profile = await getProfile();
  const name = profile?.display_name || user.email?.split("@")[0] || "You";
  return (
    <div className="flex min-h-screen flex-col md:flex-row">
      <Suspense>
        <AppSidebar user={{ name, email: user.email ?? "", avatarUrl: profile?.avatar_url }} />
      </Suspense>
      <main className="min-w-0 flex-1">{children}</main>
    </div>
  );
}
