import type { Metadata } from "next";
import { ProjectBrowser } from "@/components/dashboard/project-browser";
import { requireUser } from "@/lib/auth/session";
import { listProjects } from "@/lib/data";

export const metadata: Metadata = { title: "Dashboard" };

export default async function DashboardPage() {
  const { supabase } = await requireUser("/dashboard");
  const projects = await listProjects(supabase);
  return <ProjectBrowser initialProjects={projects} mode="dashboard" />;
}
