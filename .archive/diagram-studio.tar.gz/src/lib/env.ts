/** Public (browser-safe) configuration. */
export const publicEnv = {
  supabaseUrl: process.env.NEXT_PUBLIC_SUPABASE_URL ?? "",
  supabaseAnonKey: process.env.NEXT_PUBLIC_SUPABASE_ANON_KEY ?? "",
  appUrl: process.env.NEXT_PUBLIC_APP_URL ?? "http://localhost:3000",
  ollamaDefaultUrl: process.env.NEXT_PUBLIC_OLLAMA_DEFAULT_URL ?? "http://localhost:11434",
  ollamaDefaultModel: process.env.NEXT_PUBLIC_OLLAMA_DEFAULT_MODEL ?? "llama3.1",
};

export function assertSupabaseConfigured() {
  if (!publicEnv.supabaseUrl || !publicEnv.supabaseAnonKey) {
    throw new Error(
      "Supabase is not configured. Copy .env.example to .env.local and set NEXT_PUBLIC_SUPABASE_URL and NEXT_PUBLIC_SUPABASE_ANON_KEY.",
    );
  }
}
